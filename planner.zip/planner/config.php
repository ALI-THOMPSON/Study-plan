<?php
// Database configuration for XAMPP
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "study_planner";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}
?>